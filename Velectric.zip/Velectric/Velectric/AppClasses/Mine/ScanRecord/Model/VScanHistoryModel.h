//
//  VScanHistoryModel.h
//  Velectric
//
//  Created by LYL on 2017/3/2.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VScanHistoryModel : NSObject

//@property (nonatomic, copy) NSString *createTime;
@property (nonatomic, copy) NSString *createTimeStr;
//@property (nonatomic, copy) NSString *myCreateTime;//自己显示的时间
@property (nonatomic, copy) NSString *createTimeDetail;//新加的小时
@property (nonatomic, copy) NSString *price;
@property (nonatomic, copy) NSString *code;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *pictureUrl;

@property (nonatomic, strong) NSNumber *ident;
@property (nonatomic, strong) NSNumber *productId;
@property (nonatomic, strong) NSNumber *memberId;


@end
