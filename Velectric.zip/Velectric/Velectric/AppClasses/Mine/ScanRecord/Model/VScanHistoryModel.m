//
//  VScanHistoryModel.m
//  Velectric
//
//  Created by LYL on 2017/3/2.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import "VScanHistoryModel.h"

@implementation VScanHistoryModel

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{
             @"ident"   :   @"id"
             };
}

@end
