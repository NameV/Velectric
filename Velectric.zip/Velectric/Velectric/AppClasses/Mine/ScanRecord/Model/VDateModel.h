//
//  VDateModel.h
//  Velectric
//
//  Created by LYL on 2017/3/2.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VDateModel : NSObject

@property (nonatomic, copy) NSString *dateString;
@property (nonatomic, copy) NSString *year;
@property (nonatomic, copy) NSString *month;
@property (nonatomic, copy) NSString *day;

- (instancetype)initWithDateString:(NSString *)string;

@end
