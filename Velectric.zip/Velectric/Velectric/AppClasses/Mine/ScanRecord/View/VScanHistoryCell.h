//
//  VScanHistoryCell.h
//  Velectric
//
//  Created by LYL on 2017/3/2.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>
@class VScanHistoryModel;

@interface VScanHistoryCell : UITableViewCell

@property (nonatomic, strong) VScanHistoryModel *model;
@property (nonatomic, assign) BOOL imageHidden;//图片是否隐藏

@end
