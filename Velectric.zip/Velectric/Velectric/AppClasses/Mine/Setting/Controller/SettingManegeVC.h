//
//  SettingManegeVC.h
//  Velectric
//
//  Created by hongzhou on 2016/12/19.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import "BaseViewController.h"

@interface SettingManegeVC : BaseViewController

@end
