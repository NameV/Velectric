//
//  VMyAccountView.h
//  Velectric
//
//  Created by LYL on 2017/2/22.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>
@class VMyCardModel;

@interface VMyAccountView : UIView

@property (nonatomic, strong) UILabel *accountNumLabel;         //余额数量
@property (nonatomic, strong) UIImageView *bgImageView;         //银行卡背景
@property (nonatomic, strong) UIImageView *bankIcon;            //银行标志
@property (nonatomic, strong) UILabel *bankNameLabel;           //银行名字
@property (nonatomic, strong) UILabel *bankTypeLabel;           //银行类型
@property (nonatomic, strong) UIButton *getMoneyBtn;            //提现btn
@property (nonatomic, strong) UILabel *bankNumLabel;            //银行尾号
@property (nonatomic, strong) UIButton *bindCardBtn;             //绑卡或者解绑

@property (nonatomic, strong) VMyCardModel *cardModel;           //银行卡model

@end
