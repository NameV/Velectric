//
//  VBindCardVC.h
//  Velectric
//
//  Created by LYL on 2017/2/22.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import "BaseViewController.h"

@interface VBindCardVC : BaseViewController

@end
