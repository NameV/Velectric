//
//  VGetMoneyVC.h
//  Velectric
//
//  Created by LYL on 2017/2/24.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import "BaseViewController.h"

@interface VGetMoneyVC : BaseViewController

@end
