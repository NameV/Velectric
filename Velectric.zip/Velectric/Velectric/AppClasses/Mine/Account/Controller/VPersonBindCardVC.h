//
//  VPersonBindCardVC.h
//  Velectric
//
//  Created by LYL on 2017/2/22.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import "BaseViewController.h"

typedef enum _BindType{
    BindTypePerson = 0,     //个人绑卡
    BindTypeLittle          //小额鉴权
}BindType;

@interface VPersonBindCardVC : BaseViewController

- (instancetype)initWithType:(BindType)bindType;

@end
