//
//  VGetMoneyRecordModel.h
//  Velectric
//
//  Created by LYL on 2017/2/25.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VGetMoneyRecordModel : NSObject

@property (nonatomic, copy) NSString *code;
@property (nonatomic, copy) NSString *msg;
@property (nonatomic, strong) NSArray *recordList;  //返回的数据集合
@property (nonatomic, copy) NSString *totalPage;    //总页数
@property (nonatomic, copy) NSString *currentPage;  //当前页


@end

@interface VGetMoneyRecordmsgModel : NSObject

@property (nonatomic, copy) NSString *time;         //当前页
@property (nonatomic, copy) NSString *recordId;     //当前页
@property (nonatomic, copy) NSString *account;      //当前页

@end
