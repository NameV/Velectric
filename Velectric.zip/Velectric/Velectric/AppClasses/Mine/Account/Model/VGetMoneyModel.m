//
//  VGetMoneyModel.m
//  Velectric
//
//  Created by LYL on 2017/2/24.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import "VGetMoneyModel.h"

@implementation VGetMoneyModel

@end
