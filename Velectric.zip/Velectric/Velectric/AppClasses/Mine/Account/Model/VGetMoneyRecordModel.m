//
//  VGetMoneyRecordModel.m
//  Velectric
//
//  Created by LYL on 2017/2/25.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import "VGetMoneyRecordModel.h"

@implementation VGetMoneyRecordModel

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{
             @"recordList"   :   [VGetMoneyRecordmsgModel class]
             };
}
@end

@implementation VGetMoneyRecordmsgModel


@end
