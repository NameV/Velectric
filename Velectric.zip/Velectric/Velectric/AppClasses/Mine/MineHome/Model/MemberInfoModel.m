//
//  MemberInfoModel.m
//  Velectric
//
//  Created by hongzhou on 2017/1/5.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import "MemberInfoModel.h"

@implementation MemberInfoModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
