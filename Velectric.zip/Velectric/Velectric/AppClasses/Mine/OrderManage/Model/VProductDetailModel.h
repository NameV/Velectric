//
//  VProductDetailModel.h
//  Velectric
//
//  Created by LYL on 2017/2/28.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VProductDetailModel : NSObject

@property (nonatomic, copy)NSString *name;
@property (nonatomic, strong)NSNumber *productId;
@property (nonatomic, strong)NSArray *ogvs;

@end

@interface VProductDetailCellModel : NSObject

@property (nonatomic, copy)NSString *text;          //【规格】
@property (nonatomic, copy)NSString *imageUrl;
@property (nonatomic, copy)NSString *name;          //【名称】
@property (nonatomic, copy)NSString *promotion;
@property (nonatomic, copy)NSString *url;           //【图片路径】

@property (nonatomic, strong)NSNumber *ident;
@property (nonatomic, strong)NSNumber *weight;
@property (nonatomic, strong)NSNumber *dealPrice;   //【成交价】
@property (nonatomic, strong)NSNumber *volume;
@property (nonatomic, strong)NSNumber *subtotal;    //【商品合计】
@property (nonatomic, strong)NSNumber *productId;
@property (nonatomic, strong)NSNumber *hasLimit;
@property (nonatomic, strong)NSNumber *quantity;

@end
