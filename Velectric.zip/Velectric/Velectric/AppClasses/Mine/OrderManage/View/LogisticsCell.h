//
//  LogisticsCell.h
//  Velectric
//
//  Created by hongzhou on 2016/12/19.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@class OrderProcessModel;

@interface LogisticsCell : UITableViewCell

//圆点image
@property (strong,nonatomic) UIImageView * yuanImage;

//竖线
@property (strong,nonatomic) UIView * verticaleLine;

//内容描述
@property (strong,nonatomic) UILabel * contentlab;

//时间
@property (strong,nonatomic) UILabel * timeLab;

//订单流程model
@property (strong,nonatomic) OrderProcessModel * model;

//物流model
@property (strong,nonatomic) OrderProcessModel * logisticsModel;

@end
