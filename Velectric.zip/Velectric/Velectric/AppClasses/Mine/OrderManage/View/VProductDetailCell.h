//
//  VProductDetailCell.h
//  Velectric
//
//  Created by LYL on 2017/2/28.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VProductDetailModel.h"

@interface VProductDetailCell : UITableViewCell

@property (nonatomic, strong)VProductDetailCellModel *model;

@end
