//
//  VGetMoneyRecordCell.h
//  Velectric
//
//  Created by LYL on 2017/2/25.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VGetMoneyRecordModel.h"

@interface VGetMoneyRecordCell : UITableViewCell

@property (nonatomic, strong) VGetMoneyRecordmsgModel *model;

@end
