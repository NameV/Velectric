//
//  VMyCollectVC.h
//  Velectric
//
//  Created by LYL on 2017/2/16.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import "BaseViewController.h"

@interface VMyCollectVC : BaseViewController

@end
