//
//  VFactoryCollectModel.h
//  Velectric
//
//  Created by LYL on 2017/2/16.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VFactoryCollectModel : NSObject

@property (nonatomic, copy) NSString *loginName;        //登录名
@property (nonatomic, strong) NSArray *collectionManuacturer;
@property (nonatomic, strong) NSArray *manuacturerIds;

@end

@interface VCollectionManuacturerModel : NSObject

@property (nonatomic, copy) NSString *createTime;       //被收藏时间
@property (nonatomic, copy) NSString *manufacturerId;   //厂商id
@property (nonatomic, copy) NSString *times;            //被收藏次数
@property (nonatomic, copy) NSString *name;             //厂商名称

@end

@interface VManuacturerIdsModel : NSObject

@end
