//
//  VGoodsCollectModel.h
//  Velectric
//
//  Created by LYL on 2017/2/16.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VGoodsCollectModel : NSObject

@property (nonatomic, strong) NSArray *collectionProduct;   //产品arrar
@property (nonatomic, copy) NSString *loginName;

@end

@interface VGoodsCollectCellModel : NSObject

@property (nonatomic, copy) NSString *createTime;   //收藏时间
@property (nonatomic, copy) NSString *price;        //商品价格
@property (nonatomic, copy) NSString *pictureUrl;   //图片
@property (nonatomic, copy) NSString *name;         //产品名称
@property (nonatomic, copy) NSString *salesVolume;  //销量
@property (nonatomic, copy) NSString *productId;    //产品id

@end
