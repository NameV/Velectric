//
//  RegionModel.h
//  Velectric
//
//  Created by hongzhou on 2016/12/21.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RegionModel : NSObject

@property (assign,nonatomic) NSInteger myId;
@property (strong,nonatomic) NSString * name;

@end
