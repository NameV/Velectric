//
//  RegionModel.m
//  Velectric
//
//  Created by hongzhou on 2016/12/21.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import "RegionModel.h"

@implementation RegionModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"id"]) {
        self.myId = [value integerValue];
    }
}

@end
