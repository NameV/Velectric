//
//  PayTypeModel.m
//  Velectric
//
//  Created by hongzhou on 2017/1/9.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import "PayTypeModel.h"

@implementation PayTypeModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"description"]) {
        _descript = value;
    }
}

@end
