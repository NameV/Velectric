//
//  BankInfoModel.m
//  Velectric
//
//  Created by hongzhou on 2016/12/16.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import "BankInfoModel.h"

@implementation BankInfoModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
