//
//  QuickPayCell.h
//  Velectric
//
//  Created by hongzhou on 2016/12/16.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BankInfoModel;

@interface QuickPayCell : UITableViewCell

//银行名称
@property (strong,nonatomic) UILabel * backNameLab;
//卡尾号
@property (strong,nonatomic) UILabel * numberLab;
//银行logo
@property (strong,nonatomic) UIImageView * logoImage;
//手机
@property (strong,nonatomic) UIImageView * rightImage;
//线条
@property (strong,nonatomic) UIView * lineView;

@property (strong,nonatomic) BankInfoModel * model;

@property (strong,nonatomic) BankInfoModel * infoModel;

@end
