//
//  AddBankCardVC.h
//  Velectric
//
//  Created by hongzhou on 2016/12/16.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import "BaseViewController.h"
#import "BankInfoModel.h"

@interface AddBankCardVC : BaseViewController

@property (nonatomic, strong) BankInfoModel *bankModel;
/* mergePaymentId */
@property (nonatomic, copy) NSString *mergePaymentId;
/* 总价格 */
@property (nonatomic, copy) NSString *totalAmount;

@end
