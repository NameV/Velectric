//
//  QuickPayVC.h
//  Velectric
//
//  Created by hongzhou on 2016/12/16.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import "BaseViewController.h"

@interface QuickPayVC : BaseViewController

//订单id
@property (strong,nonatomic) NSString * mergePaymentId;

@end
