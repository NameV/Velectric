//
//  BindingBankWebViewVC.h
//  Velectric
//
//  Created by hongzhou on 2016/12/24.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import "BaseViewController.h"

@interface BindingBankWebViewVC : BaseViewController

//订单编号
@property (strong,nonatomic) NSString * mergePaymentId;
//银行key
@property (strong,nonatomic) NSString * plantBankId;

@end
