//
//  InternetPayVC.h
//  Velectric
//
//  Created by hongzhou on 2017/1/11.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import "BaseViewController.h"

@interface InternetPayVC : BaseViewController

//订单id
@property (strong,nonatomic) NSString * mergePaymentId;

@end
