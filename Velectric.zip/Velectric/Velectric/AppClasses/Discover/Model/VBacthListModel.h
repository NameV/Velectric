//
//  VBacthListModel.h
//  Velectric
//
//  Created by MacPro04967 on 2017/2/14.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VBacthListModel : NSObject

@property (nonatomic, strong) NSNumber *ident;
@property (nonatomic, strong) NSArray *batchProducts;

//- (CGFloat)cellHeight;

@end

@interface VBatchCellModel : NSObject

@property (nonatomic, assign) BOOL *isDelete;
@property (nonatomic, strong) NSNumber *ident;
@property (nonatomic, copy) NSString *remark;
@property (nonatomic, copy) NSString *context;
@property (nonatomic, copy) NSString *memberId;
@property (nonatomic, copy) NSString *createDate;
@property (nonatomic, copy) NSString *updateDate;

@property (nonatomic, assign) CGFloat cellHeight;

@end
