//
//  VbatchListCell.h
//  Velectric
//
//  Created by MacPro04967 on 2017/2/14.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VBacthListModel.h"

@interface VbatchListCell : UITableViewCell

@property (nonatomic, strong) UIButton *editBtn;//编辑
@property (nonatomic, strong) UIButton *deleteBtn;//删除

@property (nonatomic, strong) VBatchCellModel *model;

@end
