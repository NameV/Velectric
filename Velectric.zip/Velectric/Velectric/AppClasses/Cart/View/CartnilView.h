//
//  CartnilView.h
//  Velectric
//
//  Created by user on 2016/12/8.
//  Copyright © 2016年 LiuXiaoQin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CartnilView : UIView

@property (weak, nonatomic) IBOutlet UIView *bgView;

@property (weak, nonatomic) IBOutlet UIImageView *nilImageView;
@property (weak, nonatomic) IBOutlet UIButton *goIGuangGuangBtn;

@end
