//
//  CartnilView.m
//  Velectric
//
//  Created by user on 2016/12/8.
//  Copyright © 2016年 LiuXiaoQin. All rights reserved.
//

#import "CartnilView.h"

@implementation CartnilView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
