//
//  CartViewController.h
//  Velectric
//
//  Created by QQ on 2016/11/26.
//  Copyright © 2016年 LiuXiaoQin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CartViewController : BaseViewController
@property (nonatomic, copy)NSString * fromDetailFlag;//来自详情页的标子
@end
