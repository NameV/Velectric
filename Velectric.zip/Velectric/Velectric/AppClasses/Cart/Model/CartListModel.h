//
//  CartListModel.h
//  Velectric
//
//  Created by user on 2016/12/24.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import <Foundation/Foundation.h>
@class CartModel;

@interface CartListModel : NSObject


//品牌名称
@property (strong,nonatomic) NSString * brandsName;
//basketId
@property (strong,nonatomic) NSString * basketId;

@property (strong,nonatomic) NSMutableArray <CartModel *>* cartList;

@end
