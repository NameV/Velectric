//
//  LoginViewController.h
//  Velectric
//
//  Created by QQ on 2016/11/18.
//  Copyright © 2016年 LiuXiaoQin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *velectricImageView;
@property (weak, nonatomic) IBOutlet UIImageView *logoImageView;
@property (weak, nonatomic) IBOutlet UILabel *logoLable;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentedController;
@property (assign, nonatomic) int verifycodesign;

@end
