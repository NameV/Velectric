//
//  loginViewTwo.h
//  Velectric
//
//  Created by QQ on 2016/11/22.
//  Copyright © 2016年 LiuXiaoQin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface loginViewTwo : UIView
@property (weak, nonatomic) IBOutlet UITextField *accountNumberField;
@property (weak, nonatomic) IBOutlet UITextField *passField;
@property (weak, nonatomic) IBOutlet UIButton *eyeBtn;
@property (weak, nonatomic) IBOutlet UIImageView *accoutImageView;
@property (weak, nonatomic) IBOutlet UIImageView *passImageView;
@property (weak, nonatomic) IBOutlet UIView *greayLine;
@property (weak, nonatomic) IBOutlet UIView *greayLineTwo;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (weak, nonatomic) IBOutlet UIButton *remeberBtn;
@property (weak, nonatomic) IBOutlet UIImageView *yanzhengImage;
@property (weak, nonatomic) IBOutlet UITextField *yanZhengField;
@property (weak, nonatomic) IBOutlet UIButton *yanzhengBtn;
@property (weak, nonatomic) IBOutlet UIView *greayLineThree;

@end
