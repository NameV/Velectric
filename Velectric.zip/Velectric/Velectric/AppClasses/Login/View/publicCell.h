//
//  publicCell.h
//  Velectric
//
//  Created by QQ on 2016/11/23.
//  Copyright © 2016年 LiuXiaoQin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface publicCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *listLable;
@property (weak, nonatomic) IBOutlet UIImageView *listImageView;
@property (weak, nonatomic) IBOutlet UILabel *searchLable;
@property (weak, nonatomic) IBOutlet UILabel *categoryLble;
@property (nonatomic, assign)BOOL * isSelect;
@end
