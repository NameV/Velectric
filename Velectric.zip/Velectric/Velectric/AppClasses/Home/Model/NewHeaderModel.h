//
//  NewHeaderModel.h
//  Velectric
//
//  Created by hongzhou on 2017/1/9.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewHeaderModel : NSObject

//ID
@property (strong,nonatomic) NSNumber * Id;

//标题
@property (strong,nonatomic) NSString * title;

//描述
@property (strong,nonatomic) NSString * describe;

//网址
@property (strong,nonatomic) NSString * url;


@end
