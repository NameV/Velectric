//
//  HomeCategoryModel.m
//  Velectric
//
//  Created by hongzhou on 2016/12/27.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import "HomeCategoryModel.h"

@implementation HomeCategoryModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"id"]) {
        self.myId = [value integerValue];
    }
    
    if ([key isEqualToString:@"categoryName"]) {
        self.name = value;
    }
    
    if ([key isEqualToString:@"categoryId"]) {
        self.myId = [value integerValue];
    }
}

@end
