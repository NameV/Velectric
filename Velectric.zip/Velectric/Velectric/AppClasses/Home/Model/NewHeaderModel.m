//
//  NewHeaderModel.m
//  Velectric
//
//  Created by hongzhou on 2017/1/9.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import "NewHeaderModel.h"

@implementation NewHeaderModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
