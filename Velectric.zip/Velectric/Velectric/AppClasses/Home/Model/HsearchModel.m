//
//  HsearchModel.m
//  Velectric
//
//  Created by user on 2016/12/30.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import "HsearchModel.h"

@implementation HsearchModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end
