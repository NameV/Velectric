//
//  HomeTableViewCell.h
//  Velectric
//
//  Created by hongzhou on 2016/12/17.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeTableViewCell : UITableViewCell

@property (strong,nonatomic) UILabel * typeLab;                 //类型
@property (strong,nonatomic) UICollectionView * collectionView; //商品
@property (strong,nonatomic) UIButton * showMoreBtn;            //显示更多
@property (strong,nonatomic) UIView * bottomLine;               //显示更多

@end
