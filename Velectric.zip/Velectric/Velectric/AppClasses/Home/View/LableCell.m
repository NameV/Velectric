//
//  LableCell.m
//  Velectric
//
//  Created by QQ on 2016/11/29.
//  Copyright © 2016年 LiuXiaoQin. All rights reserved.
//

#import "LableCell.h"

@implementation LableCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
