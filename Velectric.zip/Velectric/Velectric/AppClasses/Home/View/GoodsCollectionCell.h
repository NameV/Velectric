//
//  GoodsCollectionCell.h
//  Velectric
//
//  Created by hongzhou on 2016/12/17.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HomeGoodsModel;

@interface GoodsCollectionCell : UICollectionViewCell

@property (strong,nonatomic) UILabel * nameLab;             //商品名
@property (strong,nonatomic) UIImageView * photoView;       //图片
@property (strong,nonatomic) UILabel * priceLab;            //价格
@property (strong,nonatomic) UIView * fengeLine;            //分割线


@property (strong,nonatomic) HomeGoodsModel * goodsModel;

@end
