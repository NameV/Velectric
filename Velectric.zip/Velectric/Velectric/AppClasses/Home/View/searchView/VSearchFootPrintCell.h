//
//  VSearchFootPrintCell.h
//  Velectric
//
//  Created by LYL on 2017/3/6.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VScanHistoryModel.h"

@interface VSearchFootPrintCell : UITableViewCell

@property (nonatomic, strong) UILabel *titleLabel;  //标题
@property (nonatomic, strong) UILabel *timeLabel;  //时间
@property (nonatomic, strong) VScanHistoryModel *model;

@end
