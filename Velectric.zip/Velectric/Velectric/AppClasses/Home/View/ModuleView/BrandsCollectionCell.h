//
//  BrandsCollectionCell.h
//  Velectric
//
//  Created by hongzhou on 2017/1/6.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BrandsCollectionCell : UICollectionViewCell

@property (strong,nonatomic) UIImageView * photoView;           //图片
@property (strong,nonatomic) UIView * verticalView;             //竖线
@property (strong,nonatomic) UIView * horizontalView1;           //横线1
@property (strong,nonatomic) UIView * horizontalView2;           //横线2

@end
