//
//  HeaderNewView.h
//  Velectric
//
//  Created by hongzhou on 2017/1/6.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NewHeaderModel;

@interface HeaderNewView : UIView

//头条list
@property (strong,nonatomic) NSMutableArray <NewHeaderModel *>* newsList;

@property (strong,nonatomic) NSMutableArray * newsLabList;

@property (strong,nonatomic) UIScrollView * scrollView;

@property (strong,nonatomic) NSTimer * timer;

@end
