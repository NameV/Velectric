//
//  AppDelegate.m
//  Velectric
//
//  Created by QQ on 2016/11/17.
//  Copyright © 2016年 LiuXiaoQin. All rights reserved.
//
//  最高级分类目录

#import <Foundation/Foundation.h>
#import "MJExtension.h"

@interface SCCategory : NSObject <MJKeyValue>
/**
 *  类别代号
 */
@property (nonatomic, copy) NSString *cid;
/**
 *  具体描述
 */
@property (nonatomic, copy) NSString *detail_description;
/**
 *  所属父类
 */
@property (nonatomic, assign) int fid;
/**
 *  图标URL
 */
@property (nonatomic, copy) NSString *icon;
/**
 *  当前类的级别
 */
@property (nonatomic, assign) int level;
/**
 *  类别名
 */
@property (nonatomic, copy) NSString *name;

@end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com
