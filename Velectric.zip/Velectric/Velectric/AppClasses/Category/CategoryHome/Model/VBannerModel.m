//
//  VBannerModel.m
//  Velectric
//
//  Created by LYL on 2017/3/8.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import "VBannerModel.h"

@implementation VBannerModel

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"ident" : @"id"};
}

@end
