//
//  AppDelegate.m
//  Velectric
//
//  Created by QQ on 2016/11/17.
//  Copyright © 2016年 LiuXiaoQin. All rights reserved.
//

#import "CommodityTableViewCell.h"

@implementation CommodityTableViewCell
- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
}


@end



