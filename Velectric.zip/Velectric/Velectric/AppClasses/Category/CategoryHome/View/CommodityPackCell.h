//
//  CommodityPackCell.h
//  jdmobile
//
//  Created by 丁博洋 on 15/6/23.
//  Copyright (c) 2015年 SYETC02. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommodityPackCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIView *btnBgView;
@property (weak, nonatomic) IBOutlet UIButton *xuanBtn;

@property (weak, nonatomic) IBOutlet UILabel *xinghaoAmoneyLable;

@property (weak, nonatomic) IBOutlet UILabel *chanpinLable;
@property (weak, nonatomic) IBOutlet UIView *bgView;
@property (weak, nonatomic) IBOutlet UILabel *piceLable;
@property (weak, nonatomic) IBOutlet UILabel *payNumBerLable;
@property (weak, nonatomic) IBOutlet UILabel *numberLable;

@end
