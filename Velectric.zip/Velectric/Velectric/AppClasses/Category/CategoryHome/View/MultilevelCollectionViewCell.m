//
//  AppDelegate.m
//  Velectric
//
//  Created by QQ on 2016/11/17.
//  Copyright © 2016年 LiuXiaoQin. All rights reserved.
//

#import "MultilevelCollectionViewCell.h"

@implementation MultilevelCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
