//
//  HeaderView.h
//  Velectric
//
//  Created by pengjingli on 16/12/1.
//  Copyright © 2016年 LiuXiaoQin. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface HeaderView : UICollectionReusableView
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UIButton *allBtn;

@end
