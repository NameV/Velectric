//
//  VBigImageCell.h
//  Velectric
//
//  Created by LYL on 2017/4/11.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VBigImageCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView *bigImage;
@property (nonatomic, strong) UIImage *kImage;

@end
