//
//  DetailsBtnView.m
//  Velectric
//
//  Created by user on 2016/12/22.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import "DetailsBtnView.h"

@implementation DetailsBtnView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
