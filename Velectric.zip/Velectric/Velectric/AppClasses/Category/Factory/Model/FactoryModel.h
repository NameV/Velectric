//
//  FactoryModel.h
//  Velectric
//
//  Created by user on 2016/12/29.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FactoryModel : NSObject

//商品名
@property (copy,nonatomic) NSString * name;

//图片的URL
@property (copy,nonatomic) NSString * pictureUrl;

//价格
@property (assign,nonatomic) CGFloat minPrice;

//商品id
@property (copy,nonatomic) NSString * Id;

//商品数量
@property (assign,nonatomic) NSInteger count;


/*
//商品名
@property (copy,nonatomic) NSString * productName_ik;

//图片的URL
@property (copy,nonatomic) NSString * defaultGoodsPictureUrl;

//价格
@property (assign,nonatomic) NSInteger price;

//商品id
@property (copy,nonatomic) NSString * Id;

//商品数量
@property (assign,nonatomic) NSInteger count;

*/
@end
