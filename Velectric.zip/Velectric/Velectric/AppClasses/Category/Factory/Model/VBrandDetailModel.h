//
//  VBrandDetailModel.h
//  Velectric
//
//  Created by LYL on 2017/3/9.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VBrandDetailModel : NSObject

@property (nonatomic, copy) NSString *name;//品牌名字
@property (nonatomic, copy) NSString *kdescription;//品牌介绍
@property (nonatomic, copy) NSString *manage;//主营业务
@property (nonatomic, copy) NSString *imageUrl;//icon图片

@end
