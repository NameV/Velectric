//
//  VBrandDetailModel.m
//  Velectric
//
//  Created by LYL on 2017/3/9.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import "VBrandDetailModel.h"

@implementation VBrandDetailModel

@end
