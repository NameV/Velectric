//
//  ScreeningCategoryViewCell2.h
//  Velectric
//
//  Created by hongzhou on 2016/12/29.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HomeCategoryModel;

@interface ScreeningCategoryViewCell2 : UITableViewCell

//名称
@property (strong,nonatomic) UILabel * nameLab;

//箭头
//@property (strong,nonatomic) UIImageView * rightImage;
@property (strong,nonatomic) UIImageView * selectView;

//底部线条
@property (strong,nonatomic) UIView * lineView;

//子级分类列表
@property (strong,nonatomic) BaseTableView * subCategoryView;

@property (strong,nonatomic) HomeCategoryModel * model;

@end
