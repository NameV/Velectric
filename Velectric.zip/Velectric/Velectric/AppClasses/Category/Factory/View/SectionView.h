//
//  SectionView.h
//  Velectric
//
//  Created by hongzhou on 2017/1/16.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HomeCategoryModel;

@interface SectionView : UIView

//名称
@property (strong,nonatomic) UILabel * nameLab;

//箭头
@property (strong,nonatomic) UIImageView * rightImage;

//底部线条
@property (strong,nonatomic) UIView * lineView;

//点击按钮
@property (strong,nonatomic) UIButton * button;

@property (assign,nonatomic)BOOL  fromFactoryFlage;

@property (strong,nonatomic) HomeCategoryModel * model;

@end
