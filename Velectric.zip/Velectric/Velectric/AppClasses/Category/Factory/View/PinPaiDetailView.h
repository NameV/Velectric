//
//  PinPaiDetailView.h
//  Velectric
//
//  Created by QQ on 2016/12/6.
//  Copyright © 2016年 LiuXiaoQin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PinPaiDetailView : UIView
@property (weak, nonatomic) IBOutlet UIImageView *beijingImage;
@property (weak, nonatomic) IBOutlet UIImageView *touXiangImage;
@property (weak, nonatomic) IBOutlet UILabel *titleLable;
@property (weak, nonatomic) IBOutlet UILabel *contentLable;
@property (weak, nonatomic) IBOutlet UIImageView *bigImage;
@property (weak, nonatomic) IBOutlet UILabel *pinpaiInfoLable;
@property (weak, nonatomic) IBOutlet UILabel *pinpaiJieshaoLable;
@property (weak, nonatomic) IBOutlet UILabel *renZhengLable;
@property (weak, nonatomic) IBOutlet UIButton *shouQiBtn;

@end
