//
//  ScreeningViewCell.h
//  Velectric
//
//  Created by hongzhou on 2016/12/29.
//  Copyright © 2016年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SkuPropertyModel;

@interface ScreeningViewCell : UITableViewCell

//白色背景
@property (strong,nonatomic) UIView * bgView;

//名称
@property (strong,nonatomic) UILabel * titleLab;

//全部
@property (strong,nonatomic) UILabel * allLab;

//选中 属性名称
@property (strong,nonatomic) UILabel * propertyNameLab;

//箭头
@property (strong,nonatomic) UIImageView * rightImage;

//属性集合 view
@property (strong,nonatomic) UIView * propertyView;

//展开按钮
@property (strong,nonatomic) UIButton * expandBtn;

@property (strong,nonatomic) SkuPropertyModel * model;

@end
