//
//  ScreeningCategoryViewCell3.h
//  Velectric
//
//  Created by hongzhou on 2017/1/15.
//  Copyright © 2017年 hongzhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HomeCategoryModel;

@interface ScreeningCategoryViewCell3 : UITableViewCell

//名称
@property (strong,nonatomic) UILabel * nameLab;

//箭头
@property (strong,nonatomic) UIImageView * selectView;

//底部线条
@property (strong,nonatomic) UIView * lineView;

@property (strong,nonatomic) HomeCategoryModel * model;

@end
