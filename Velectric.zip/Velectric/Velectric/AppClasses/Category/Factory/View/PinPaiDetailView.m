//
//  PinPaiDetailView.m
//  Velectric
//
//  Created by QQ on 2016/12/6.
//  Copyright © 2016年 LiuXiaoQin. All rights reserved.
//

#import "PinPaiDetailView.h"

@implementation PinPaiDetailView



@end
